BEGIN TRANSACTION;



INSERT INTO BD_AUTH_MANAGER.dbo.AUTHM_UTL_TRANSACTION_TYPE_CONFIGURATION
(TTC_ID, TTY_ID, CTY_ID, TTC_VALUE, TTC_ORDER, TTY_DESCRIPTION, TTY_MESSAGE)
VALUES(8010, 8, 14, N'GET http://ibsbcaempia9.uatchl.bns:9080/baas-massive-payment/api/v1/paysheet/status/modification?paysheetid={data.paysheet_id}&originsystem={data.secondary_code}&codconv={data.code_agreement}', 1, N'Servicio para cambio de estado cuándo se elimina manualmente nóminas de pagos masivos en BEL', NULL);
INSERT INTO BD_AUTH_MANAGER.dbo.AUTHM_UTL_TRANSACTION_TYPE_CONFIGURATION
(TTC_ID, TTY_ID, CTY_ID, TTC_VALUE, TTC_ORDER, TTY_DESCRIPTION, TTY_MESSAGE)
VALUES(10010, 10, 14, N'GET http://ibsbcaempia9.uatchl.bns:9080/baas-massive-payment/api/v1/paysheet/status/modification?paysheetid={data.paysheet_id}&originsystem={data.secondary_code}&codconv={data.code_agreement}', 1, N'Servicio para cambio de estado cuándo se elimina manualmente nóminas de pagos masivos en BEL', NULL);
INSERT INTO BD_AUTH_MANAGER.dbo.AUTHM_UTL_TRANSACTION_TYPE_CONFIGURATION
(TTC_ID, TTY_ID, CTY_ID, TTC_VALUE, TTC_ORDER, TTY_DESCRIPTION, TTY_MESSAGE)
VALUES(11010, 11, 14, N'GET http://ibsbcaempia9.uatchl.bns:9080/baas-massive-payment/api/v1/paysheet/status/modification?paysheetid={data.paysheet_id}&originsystem={data.secondary_code}&codconv={data.code_agreement}', 1, N'Servicio para cambio de estado cuándo se elimina manualmente nóminas de pagos masivos en BEL', NULL);
INSERT INTO BD_AUTH_MANAGER.dbo.AUTHM_UTL_TRANSACTION_TYPE_CONFIGURATION
(TTC_ID, TTY_ID, CTY_ID, TTC_VALUE, TTC_ORDER, TTY_DESCRIPTION, TTY_MESSAGE)
VALUES(12010, 12, 14, N'GET http://ibsbcaempia9.uatchl.bns:9080/baas-massive-payment/api/v1/paysheet/status/modification?paysheetid={data.paysheet_id}&originsystem={data.secondary_code}&codconv={data.code_agreement}', 1, N'Servicio para cambio de estado cuándo se elimina manualmente nóminas de pagos masivos en BEL', NULL);
INSERT INTO BD_AUTH_MANAGER.dbo.AUTHM_UTL_TRANSACTION_TYPE_CONFIGURATION
(TTC_ID, TTY_ID, CTY_ID, TTC_VALUE, TTC_ORDER, TTY_DESCRIPTION, TTY_MESSAGE)
VALUES(13010, 13, 14, N'GET http://ibsbcaempia9.uatchl.bns:9080/baas-massive-payment/api/v1/paysheet/status/modification?paysheetid={data.paysheet_id}&originsystem={data.secondary_code}&codconv={data.code_agreement}', 1, N'Servicio para cambio de estado cuándo se elimina manualmente nóminas de pagos masivos en BEL', NULL);
INSERT INTO BD_AUTH_MANAGER.dbo.AUTHM_UTL_TRANSACTION_TYPE_CONFIGURATION
(TTC_ID, TTY_ID, CTY_ID, TTC_VALUE, TTC_ORDER, TTY_DESCRIPTION, TTY_MESSAGE)
VALUES(14010, 14, 14, N'GET http://ibsbcaempia9.uatchl.bns:9080/baas-massive-payment/api/v1/paysheet/status/modification?paysheetid={data.paysheet_id}&originsystem={data.secondary_code}&codconv={data.code_agreement}', 1, N'Servicio para cambio de estado cuándo se elimina manualmente nóminas de pagos masivos en BEL', NULL);
INSERT INTO BD_AUTH_MANAGER.dbo.AUTHM_UTL_TRANSACTION_TYPE_CONFIGURATION
(TTC_ID, TTY_ID, CTY_ID, TTC_VALUE, TTC_ORDER, TTY_DESCRIPTION, TTY_MESSAGE)
VALUES(27010, 27, 14, N'GET http://ibsbcaempia9.uatchl.bns:9080/baas-massive-payment/api/v1/paysheet/status/modification?paysheetid={data.paysheet_id}&originsystem={data.secondary_code}&codconv={data.code_agreement}', 1, N'Servicio para cambio de estado cuándo se elimina manualmente nóminas de pagos masivos en BEL', NULL);
INSERT INTO BD_AUTH_MANAGER.dbo.AUTHM_UTL_TRANSACTION_TYPE_CONFIGURATION
(TTC_ID, TTY_ID, CTY_ID, TTC_VALUE, TTC_ORDER, TTY_DESCRIPTION, TTY_MESSAGE)
VALUES(50011, 50, 14, N'GET http://ibsbcaempia9.uatchl.bns:9080/baas-massive-payment/api/v1/paysheet/status/modification?paysheetid={data.paysheet_id}&originsystem={data.secondary_code}&codconv={data.code_agreement}', 1, N'Servicio para cambio de estado cuándo se elimina manualmente nóminas de pagos masivos en BEL', NULL);

COMMIT TRANSACTION;


SET IDENTITY_INSERT BD_AUTH_MANAGER.dbo.AUTHM_UTL_TRANSACTION_TYPE_CONFIGURATION OFF;

SELECT x.* FROM BD_AUTH_MANAGER.dbo.AUTHM_UTL_TRANSACTION_TYPE_CONFIGURATION x
WHERE TTY_ID in (8,10,11,12,13,14,50) and CTY_ID in (1,14);



UPDATE BD_AUTH_MANAGER.dbo.AUTHM_UTL_TRANSACTION_TYPE_CONFIGURATION
SET TTC_VALUE=N'POST http://ibsbcaempia9.uatchl.bns:9080/baas-massive-payment/api/v1/cashmanagement/paysheet'
WHERE TTC_ID=8000;