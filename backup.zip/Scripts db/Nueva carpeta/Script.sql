SELECT top 100 *
FROM BD_ENTLOGTRX.dbo.NEG_DATALOG logg
where logg.DAT_NAMESPACE like '%baas-factoring%'
--and logg.DAT_ENTERPRISE like '%84865000%'
order by logg.DAT_CREATED_DATE desc;

SELECT top 100 *
FROM BD_ENTLOGTRX.dbo.NEG_DATALOG logg
where logg.DAT_NAMESPACE like '%baas-factoring%'
and logg.DAT_DATA like '%CERTIFICATE%'
order by logg.DAT_CREATED_DATE desc;

SELECT x.* FROM BD_AUTH_MANAGER.dbo.AUTHM_BNS_TRANSACTION x
WHERE TRA_KEY ='930770000-089A98A2-0367-4A2F-BF96-CF5C71EFC96D';