SELECT amtmd.TMD_CODE, autmt.TMT_LABEL, amtmd.TMD_MESSAGE
            FROM AUTHM_MIT_TRANSACTION_MESSAGE amtmd,
                 TmpDynamicData tdd,
                 AUTHM_UTL_TRANSACTION_MESSAGE_TYPE autmt,
                 AUTHM_BNS_TRANSACTION trx, AUTHM_UTL_TRANSACTION_TYPE autt 
            WHERE-- trx.TRA_KEY = @TrxKey
               amtmd.TTY_ID = trx.TTY_ID
              AND amtmd.TMT_ID = 3
              AND tdd.DYNAMIC_VALUE = amtmd.TMD_CODE
              AND autmt.TMT_ID = amtmd.TMT_ID;
             
             SELECT x.* FROM BD_AUTH_MANAGER.dbo.AUTHM_UTL_TRANSACTION_TYPE x;
            SELECT x.* FROM BD_AUTH_MANAGER.dbo.AUTHM_UTL_TRANSACTION_TYPE x;
             
               BD_AUTH_MANAGER.dbo.AUTHM_UTL_PRODUCT_TYPE
               
               ;
               
SELECT x.* FROM BD_AUTH_MANAGER.dbo.AUTHM_BNS_TRANSACTION x
inner join dbo.AUTHM_UTL_STATUS sta ON sta.STA_ID  = x.STA_ID 
inner join dbo.AUTHM_UTL_TRANSACTION_TYPE autt ON autt.TTY_ID = x.TTY_ID 
inner join dbo.AUTHM_UTL_TRANSACTION_TYPE_CONFIGURATION auttc on auttc.TTY_ID = autt.TTY_ID 
where TRA_KEY ='930770000-4486C44B-F28D-4FA3-B6DE-8295F91970DB';


{"numberagreement":"0000000000970001682","amount":13000000,"currency":"CLP","agreementcode":"002 - PROVEEDORES METSO MINERALS CHILE S.A","rosterDescription":"test12344","numRecords":"2","paymentDate":"15/10/2024","paysheet_id":"20241007165442060000","confirmingType":"Confirming Electrónico","code_agreement":"002",
"secondary_code":"MPGO","rut_agreement":"930770000"}

//{"numberagreement":"0000000000970001682","amount":13000000,"currency":"CLP","agreementcode":"002 - PROVEEDORES METSO MINERALS CHILE S.A","rosterDescription":"TEST1234456","numRecords":"2","paymentDate":"16/10/2024","paysheet_id":"20241011094044002000","confirmingType":"Confirming Electrónico","code_agreement":"002","secondary_code":"MPGO","rut_agreement":"930770000"}

SELECT * FROM BD_AUTH_MANAGER.dbo.AUTHM_BNS_TRANSACTION_DATA abtd 
where TRA_ID = 44253150;

SELECT * FROM BD_AUTH_MANAGER.dbo.AUTHM_UTL_TRANSACTION_TYPE_CONFIGURATION auttc 
where TTC_ID = 50;

SELECT x.* FROM BD_AUTH_MANAGER.dbo.AUTHM_UTL_TRANSACTION_TYPE_CONFIGURATION x
where TTY_ID = 42
ORDER BY x.TTY_ID DESC

SELECT x.* FROM BD_AUTH_MANAGER.dbo.AUTHM_BNS_TRANSACTION_DATA x
WHERE DTY_ID = 1;

SELECT x.* FROM BD_AUTH_MANAGER.dbo.AUTHM_BNS_TRANSACTION_DATA x
WHERE TRA_ID = 31742475 AND DTY_ID = 1;


 

--SP AUTHM_SP_ADD_SIGN_TRANSACTION_JSON
--SP AUTHM_SP_QUERY_TRANSACTION_TYPE
--SP AUTHM_SP_QUERY_TRANSACTION_TYPE CONF_PRE_EXECUTE
--SP AUTHM_SP_QUERY_TRANSACTION_TYPE CONF_MONITOR_PLUS
--SP AUTHM_SP_GET_TRX_EXECUTION_PERMISSION
