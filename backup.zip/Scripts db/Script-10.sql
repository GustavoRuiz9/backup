SELECT * FROM BD_AUTH_MANAGER.dbo.AUTHM_BNS_TRANSACTION_DATA abtd 
where TRA_ID = 44290192;

SELECT x.* FROM BD_AUTH_MANAGER.dbo.AUTHM_BNS_TRANSACTION x
inner join dbo.AUTHM_UTL_STATUS sta ON sta.STA_ID  = x.STA_ID 
inner join dbo.AUTHM_UTL_TRANSACTION_TYPE autt ON autt.TTY_ID = x.TTY_ID 
inner join dbo.AUTHM_UTL_TRANSACTION_TYPE_CONFIGURATION auttc on auttc.TTY_ID = autt.TTY_ID 
where TRA_KEY ='713262005-60DBF95E-902C-4A7D-A642-28ACAA40391B';

---{"receipt":[],"origin_account":{"number":"40008918","type":"CTACTE","currency":"CLP"},"destination_account":[{"amount":10000,"number":"1950273002","type":"CTACTE","currency":"CLP","addressee":{"id":4371840,"name":"gua1","email":"gustavo.ruiz@imagemaker.com","rut":"51926625"},"message":"test tef duplicado","bank_id":"12","bank_name":"BANCO DEL ESTADO DE CHILE"}]}
--[{"date":null,"confirmationNumber":null,"status":5068,"transferStatus":"ERROR","exchange":null,"cashAdvanceFee":null,"message":null,"serverStatusCode":null,"statusDescription":"SERVICE REJECTED BANK","restriction":null}]


SELECT x.* FROM BD_AUTH_MANAGER.dbo.AUTHM_UTL_TRANSACTION_TYPE_CONFIGURATION x WHERE TTY_ID in (8,10,11,12,14,50) AND CTY_ID IN (3,6);

/** horaririo 23:59
 pago remuneraciones, 8
pago proveedores, 11
otros pagos, 12
rol privado, 14
nómina mismo día, 10
confirming 50
 */*//