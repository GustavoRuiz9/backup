SELECT
		register_id,
		addressee_rut,
		addressee_name,
		addressee_alias,
		payment_type,
		acc_numbr,
		acc_type,
		adr_email,
		bank_id,
		--IIF(currency IS NULL, 'CLP', currency) AS currency,
		branch_id
		FROM
		(
			SELECT
				vie.register_id,
				vie.addressee_rut,
				vie.addressee_name,
				vie.addressee_alias,
				vie.payment_type,
				vie.key_detalle,
				vie.detail,
				apr.active
			FROM adr_detail_view vie
			INNER JOIN dbo.ADR_PAYMENT_REGISTER apr ON (apr.register_id = vie.register_id)
			WHERE customer_id like   '%93077000%'
				AND payment_type IN (SELECT splitdata FROM STRING_SPLIT(1, ','))
		) d
		PIVOT
		(
			MAX(detail)
			FOR key_detalle IN (acc_numbr, acc_type, adr_email, bank_id, currency, branch_id)
		) piv
		
		
		SELECT * FROM dbo.ADR_PAYMENT_REGISTER PRE 
INNER JOIN dbo.ADR_REGISTER REG ON (REG.ADR_ID = PRE.ADR_ID)
INNER JOIN dbo.ADR_PAYMENT_DETAIL BNK ON (BNK.REGISTER_ID = PRE.REGISTER_ID AND BNK.PAYMENT_KEY = 'bank_id   ')
INNER JOIN dbo.ADR_PAYMENT_DETAIL ACC ON (ACC.REGISTER_ID = PRE.REGISTER_ID AND ACC.PAYMENT_KEY = 'acc_numbr ')
INNER JOIN dbo.ADR_PAYMENT_FOR_ADDRESSEE MET ON (MET.REGISTER_ID = PRE.REGISTER_ID AND MET.ID_PAYMENT_METHOD != '4')
WHERE --REG.CUSTOMER_ID like '%591885804%' AND REG.ADR_RUT like '%0174848467%'
--AND BNK.VALUE = 12 AND ACC.VALUE = '17484846'
 PRE.ALIAS like 'rtere';
--REG.ADR_RUT like '%05192662%';

WITH DuplicateRecords AS (
    SELECT 
        PRE.REGISTER_ID, 
        PRE.ADR_ID, 
        PRE.ALIAS, 
        PRE.RENAME, 
        BNK.VALUE AS BANK_ID,
        ACC.VALUE AS ACC_NUM,
        TYPE_ACC.VALUE AS ACC_TYPE,
        REG.CUSTOMER_ID,
        REG.ADR_RUT AS RUT,
        MET.ID_PAYMENT_METHOD AS PAYMENT_METHOD,
        COUNT(*) OVER (
            PARTITION BY REG.CUSTOMER_ID, REG.ADR_RUT, BNK.VALUE, ACC.VALUE, TYPE_ACC.VALUE, MET.ID_PAYMENT_METHOD
        ) AS GroupCount,
        ROW_NUMBER() OVER (
            PARTITION BY REG.CUSTOMER_ID, REG.ADR_RUT, BNK.VALUE, ACC.VALUE, TYPE_ACC.VALUE, MET.ID_PAYMENT_METHOD
            ORDER BY PRE.ALIAS ASC
        ) AS RowNum
    FROM dbo.ADR_PAYMENT_REGISTER PRE
    INNER JOIN dbo.ADR_REGISTER REG ON REG.ADR_ID = PRE.ADR_ID
    INNER JOIN dbo.ADR_PAYMENT_DETAIL BNK ON BNK.REGISTER_ID = PRE.REGISTER_ID 
        AND BNK.PAYMENT_KEY = 'bank_id   '
    INNER JOIN dbo.ADR_PAYMENT_DETAIL ACC ON ACC.REGISTER_ID = PRE.REGISTER_ID 
        AND ACC.PAYMENT_KEY = 'acc_numbr '
    INNER JOIN dbo.ADR_PAYMENT_DETAIL TYPE_ACC ON TYPE_ACC.REGISTER_ID = PRE.REGISTER_ID 
        AND TYPE_ACC.PAYMENT_KEY = 'acc_type  '
    INNER JOIN dbo.ADR_PAYMENT_FOR_ADDRESSEE MET ON MET.REGISTER_ID = PRE.REGISTER_ID
    	    		  -- WHERE REG.CUSTOMER_ID = '076960376K'

    --WHERE TYPE_ACC.VALUE != '06000' and TYPE_ACC.VALUE != '01000'
    --WHERE REG.CUSTOMER_ID = '713262005' -- para prueba de un customer puntual
    and PRE.ALIAS like 'Georges' -- para prueba de un registro en qa 
)
SELECT *
FROM DuplicateRecords;