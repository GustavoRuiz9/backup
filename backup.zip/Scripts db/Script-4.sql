SELECT x.* FROM BD_AUTH_MANAGER.dbo.AUTHM_BNS_TRANSACTION x
inner join dbo.AUTHM_UTL_STATUS sta ON sta.STA_ID  = x.STA_ID 
inner join dbo.AUTHM_UTL_TRANSACTION_TYPE autt ON autt.TTY_ID = x.TTY_ID 
inner join dbo.AUTHM_UTL_TRANSACTION_TYPE_CONFIGURATION auttc on auttc.TTY_ID = autt.TTY_ID 
where TRA_KEY ='713262005-60DBF95E-902C-4A7D-A642-28ACAA40391B';

//

{"numberagreement":"0000000000970001682","amount":13000000,"currency":"CLP","agreementcode":"004 - 1350040000 PROVEEDORES",
"rosterDescription":"prueba","numRecords":"2","paymentDate":"30/10/2024","paysheet_id":"20241009143916168000",
"confirmingType":"Confirming Exclusivo","code_agreement":"004","secondary_code":"MPGO","rut_agreement":"930770000"}

{"numberagreement":"0000000000970001682","amount":3000065,"currency":"CLP","agreementcode":"003 - 003 - Remuneraciones Metso Minerals Chile S.a","rosterDescription":"Prueba","numRecords":"2","paymentDate":"02 Dic, 2024","paysheet_id":"20241112105120550000","code_agreement":"3","secondary_code":"PER","rut_agreement":"00930770000"}

SELECT * FROM BD_AUTH_MANAGER.dbo.AUTHM_BNS_TRANSACTION_DATA abtd 
where TRA_ID = 33694803;

SELECT * FROM BD_AUTH_MANAGER.dbo.AUTHM_UTL_TRANSACTION_TYPE_CONFIGURATION auttc 
where TTC_ID = 50;

SELECT x.* FROM BD_AUTH_MANAGER.dbo.AUTHM_UTL_TRANSACTION_TYPE_CONFIGURATION x
where TTC_ID = 50
ORDER BY x.TTY_ID DESC

SELECT x.* FROM BD_AUTH_MANAGER.dbo.AUTHM_BNS_TRANSACTION_DATA x
WHERE TRA_ID = 44252771 AND DTY_ID = 1;

dbo.AUTHM_UTL_TRANSACTION_TYPE_CONFIGURATION

SELECT x.* FROM BD_AUTH_MANAGER.dbo.AUTHM_UTL_CONFIGURATION_TYPE x
WHERE CTY_ID = 14;

INSERT INTO BD_AUTH_MANAGER.dbo.AUTHM_UTL_TRANSACTION_TYPE_CONFIGURATION
(TTC_ID, TTY_ID, CTY_ID, TTC_VALUE, TTC_ORDER, TTY_DESCRIPTION, TTY_MESSAGE)
VALUES(50011, 50, 14, N'GET http://10.34.16.35:9083/bff-massive-payment/api/paysheet/status/modification?paysheetid={data.paysheet_id}&originsystem={data.secondary_code}&codconv={data.code_agreement}', 1, N'Servicio para cambio de estado cuándo se elimina manualmente nóminas de pagos masivos en BEL', NULL);

BEGIN TRANSACTION;

-- Realizar las operaciones SQL aquí

COMMIT TRANSACTION;

SET IDENTITY_INSERT BD_AUTH_MANAGER.dbo.AUTHM_UTL_TRANSACTION_TYPE_CONFIGURATION OFF;




UPDATE BD_AUTH_MANAGER.dbo.AUTHM_UTL_TRANSACTION_TYPE_CONFIGURATION
SET TTY_ID=8, CTY_ID=1, TTC_VALUE=N'POST http://localhost:9083/baas-massive-payment/api/v1/cashmanagement/paysheet', TTC_ORDER=1, TTY_DESCRIPTION=N'Servicio para la ejecución de pagos de remuneraciones', TTY_MESSAGE=NULL
WHERE TTC_ID=8000;
UPDATE BD_AUTH_MANAGER.dbo.AUTHM_UTL_TRANSACTION_TYPE_CONFIGURATION
SET TTY_ID=10, CTY_ID=1, TTC_VALUE=N'POST http://localhost:9083/baas-massive-payment/api/v1/cashmanagement/paysheet', TTC_ORDER=1, TTY_DESCRIPTION=N'Servicio para la ejecución de nóminas de mismo dia', TTY_MESSAGE=NULL
WHERE TTC_ID=10000;
UPDATE BD_AUTH_MANAGER.dbo.AUTHM_UTL_TRANSACTION_TYPE_CONFIGURATION
SET TTY_ID=11, CTY_ID=1, TTC_VALUE=N'POST http://localhost:9083/baas-massive-payment/api/v1/cashmanagement/paysheet', TTC_ORDER=1, TTY_DESCRIPTION=N'Servicio para la ejecución multipago (Pago de proveedores)', TTY_MESSAGE=NULL
WHERE TTC_ID=11000;
UPDATE BD_AUTH_MANAGER.dbo.AUTHM_UTL_TRANSACTION_TYPE_CONFIGURATION
SET TTY_ID=12, CTY_ID=1, TTC_VALUE=N'POST http://localhost:9083/baas-massive-payment/api/v1/cashmanagement/paysheet', TTC_ORDER=1, TTY_DESCRIPTION=N'Servicio para la ejecución multipago (Otros pagos)', TTY_MESSAGE=NULL
WHERE TTC_ID=12000;
UPDATE BD_AUTH_MANAGER.dbo.AUTHM_UTL_TRANSACTION_TYPE_CONFIGURATION
SET TTY_ID=13, CTY_ID=1, TTC_VALUE=N'POST http://localhost:9083/baas-massive-payment/api/v1/cashmanagement/paysheet', TTC_ORDER=1, TTY_DESCRIPTION=N'Servicio para la ejecución multipago (Pagos masivos)', TTY_MESSAGE=NULL
WHERE TTC_ID=13000;
UPDATE BD_AUTH_MANAGER.dbo.AUTHM_UTL_TRANSACTION_TYPE_CONFIGURATION
SET TTY_ID=14, CTY_ID=1, TTC_VALUE=N'POST http://localhost:9083/baas-massive-payment/api/v1/cashmanagement/paysheet', TTC_ORDER=1, TTY_DESCRIPTION=N'Servicio para la ejecución multipago (Rol privado)', TTY_MESSAGE=NULL
WHERE TTC_ID=14000;
UPDATE BD_AUTH_MANAGER.dbo.AUTHM_UTL_TRANSACTION_TYPE_CONFIGURATION
SET TTY_ID=50, CTY_ID=1, TTC_VALUE=N'POST http://localhost:9083/baas-massive-payment/api/v1/cashmanagement/paysheet', TTC_ORDER=1, TTY_DESCRIPTION=N'Servicio para la ejecución de transacciones de carga de nómina confirming', TTY_MESSAGE=NULL
WHERE TTC_ID=50001;

commit;
SELECT x.* FROM BD_AUTH_MANAGER.dbo.AUTHM_UTL_TRANSACTION_TYPE_CONFIGURATION x WHERE TTY_ID in (8,10,11,12,13,14,27,50);

