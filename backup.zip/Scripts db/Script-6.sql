select conf.* from BD_AUTH_MANAGER.dbo.AUTHM_UTL_TRANSACTION_TYPE_CONFIGURATION conf where TTY_ID in (8,10,11,12,14,50) and CTY_ID in (3,6)

SELECT GETDATE();

UPDATE BD_AUTH_MANAGER.dbo.AUTHM_UTL_TRANSACTION_TYPE_CONFIGURATION
SET TTC_VALUE=N'08:00:00/20:00:00', TTY_MESSAGE=N'Por favor, inténtelo más tarde. En este momento, no es posible ejecutar esta operación.'
WHERE TTC_ID=8002 AND TTY_ID=8 AND CTY_ID=3;

UPDATE BD_AUTH_MANAGER.dbo.AUTHM_UTL_TRANSACTION_TYPE_CONFIGURATION
SET TTC_VALUE=N'08:00:00/20:00:00', TTY_MESSAGE=N'Por favor, inténtelo más tarde. En este momento, no es posible ejecutar esta operación.'
WHERE TTC_ID=8004 AND TTY_ID=8 AND CTY_ID=6

UPDATE BD_AUTH_MANAGER.dbo.AUTHM_UTL_TRANSACTION_TYPE_CONFIGURATION
SET TTC_VALUE=N'08:00:00/20:00:00', TTY_MESSAGE=N'Por favor, inténtelo más tarde. En este momento, no es posible ejecutar esta operación.'
WHERE TTC_ID=10002 AND TTY_ID=10 AND CTY_ID=3;

UPDATE BD_AUTH_MANAGER.dbo.AUTHM_UTL_TRANSACTION_TYPE_CONFIGURATION
SET TTC_VALUE=N'08:00:00/20:00:00', TTY_MESSAGE=N'Por favor, inténtelo más tarde. En este momento, no es posible ejecutar esta operación.'
WHERE TTC_ID=10004 AND TTY_ID=10 AND CTY_ID=6;

UPDATE BD_AUTH_MANAGER.dbo.AUTHM_UTL_TRANSACTION_TYPE_CONFIGURATION
SET TTC_VALUE=N'08:00:00/20:00:00', TTY_MESSAGE=N'Por favor, inténtelo más tarde. En este momento, no es posible ejecutar esta operación.'
WHERE TTC_ID=11002 AND TTY_ID=11 AND CTY_ID=3;

UPDATE BD_AUTH_MANAGER.dbo.AUTHM_UTL_TRANSACTION_TYPE_CONFIGURATION
SET TTC_VALUE=N'08:00:00/20:00:00', TTY_MESSAGE=N'Por favor, inténtelo más tarde. En este momento, no es posible ejecutar esta operación.'
WHERE TTC_ID=11004 AND TTY_ID=11 AND CTY_ID=6;

UPDATE BD_AUTH_MANAGER.dbo.AUTHM_UTL_TRANSACTION_TYPE_CONFIGURATION
SET TTC_VALUE=N'08:00:00/20:00:00', TTY_MESSAGE=N'Por favor, inténtelo más tarde. En este momento, no es posible ejecutar esta operación.'
WHERE TTC_ID=12002 AND TTY_ID=12 AND CTY_ID=3;

UPDATE BD_AUTH_MANAGER.dbo.AUTHM_UTL_TRANSACTION_TYPE_CONFIGURATION
SET TTC_VALUE=N'08:00:00/20:00:00', TTY_MESSAGE=N'Por favor, inténtelo más tarde. En este momento, no es posible ejecutar esta operación.'
WHERE TTC_ID=12004 AND TTY_ID=12 AND CTY_ID=6;

UPDATE BD_AUTH_MANAGER.dbo.AUTHM_UTL_TRANSACTION_TYPE_CONFIGURATION
SET TTC_VALUE=N'08:00:00/20:00:00', TTY_MESSAGE=N'Por favor, inténtelo más tarde. En este momento, no es posible ejecutar esta operación.'
WHERE TTC_ID=14002 AND TTY_ID=14 AND CTY_ID=3;

UPDATE BD_AUTH_MANAGER.dbo.AUTHM_UTL_TRANSACTION_TYPE_CONFIGURATION
SET TTC_VALUE=N'08:00:00/20:00:00', TTY_MESSAGE=N'Por favor, inténtelo más tarde. En este momento, no es posible ejecutar esta operación.'
WHERE TTC_ID=14004 AND TTY_ID=14 AND CTY_ID=6;

UPDATE BD_AUTH_MANAGER.dbo.AUTHM_UTL_TRANSACTION_TYPE_CONFIGURATION
SET TTC_VALUE=N'08:00:00/20:00:00', TTY_MESSAGE=N'Por favor, inténtelo más tarde. En este momento, no es posible ejecutar esta operación.'
WHERE TTC_ID=50003 AND TTY_ID=50 AND CTY_ID=3;

UPDATE BD_AUTH_MANAGER.dbo.AUTHM_UTL_TRANSACTION_TYPE_CONFIGURATION
SET TTC_VALUE=N'08:00:00/20:00:00', TTY_MESSAGE=N'Por favor, inténtelo más tarde. En este momento, no es posible ejecutar esta operación.'
WHERE TTC_ID=50005 AND TTY_ID=50 AND CTY_ID=6;

SELECT tra.TRA_ID, tra.TRA_KEY TRA_CUSTOMER_KEY, TRA_USER_CREATED
from  BD_AUTH_MANAGER.dbo.AUTHM_BNS_TRANSACTION tra
/*inner join BD_AUTH_MANAGER.dbo.AUTHM_UTL_STATUS sta ON sta.STA_ID = tra.STA_ID 
inner join BD_AUTH_MANAGER.dbo.AUTHM_UTL_TRANSACTION_TYPE tty ON tty.TTY_ID = tra.TRA_ID 
inner join BD_AUTH_MANAGER.dbo.AUTHM_UTL_TRANSACTION_TYPE_CONFIGURATION conf ON conf.TTY_ID = tty.TTY_ID*/
where tra.TRA_KEY = '713262005-F0F113B4-1653-4AA6-95A0-7E1C49218C2A';


select * from BD_AUTH_MANAGER.dbo.AUTHM_BNS_TRANSACTION_DATA abtd where 
TRA_ID = 44288439;


//{"receipt":[],"origin_account":{"number":"40016147","type":"CTACTE","currency":"CLP"},"destination_account":[{"amount":123,"number":"1800217002","type":"CTACTE","currency":"CLP","addressee":{"id":1623225,"name":"PROVEEDORES INTEGRALES PRISA SA","email":"DSALASE@PRISA.CL","rut":"965569405"},"message":"test","bank_id":"001","bank_name":"BANCO DE CHILE"}]}
[{"date":"2025-02-21 09:56:12","confirmationNumber":"00000001340307869","status":0,"transferStatus":"EXECUTED","exchange":null,"cashAdvanceFee":null,"message":null,"serverStatusCode":null,"statusDescription":null,"restriction":{"isOldBeneficiary":true,"maxAmount":null}}]
{"customer":{"rut":"0727256008","name":"ERICA MENDOZA RUIZ","cellphone":"995627948","email":"ericamendoza@fjp.cl","account":{"number":"00000000000040016147","product_code":"CC"},"internet_user":"0124573092","internal_code":"0727256008","person_type":"J","ip_connection":"","linking_date":1606079202047,"session_id":""},"security":{"challenge_sent":"S","challenge_passed":"S","authorizer_type":"scotiapass"},"transaction":{"origin":"WEB","code":"TEF","datetime":1740142568707,"correlative":44288433,"amount":{"currency_type":"CLP","total_local_currency":123.0,"total_usd_currency":0.0,"total_other_currency":0.0,"conversion_rate":0.0},"recipient":{"rut":"0965569405","name":"PROVEEDORES INTEGRALES PRISA SA","account":{"number":"00000000001800217002","bank_id":"001","product_code":"CC"},"email":"DSALASE@PRISA.CL"},"is_national":true,"realtime_indicator":"S"},"host":{"code_response":"00"},"platform":{"user":"0124573092","user_name":"ERICA MENDOZA RUIZ","user_type":"0001"}}