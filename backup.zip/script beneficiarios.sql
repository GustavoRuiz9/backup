USE BD_PORTALPYME
GO
/*------------------------------------------------------------------*/
/* Version      : Diego Olave					                    */
/* Fecha		: 05/03/2025				                        */
/* Tablas       : BD_ADMAPF.dbo.ADR_PAYMENT_DETAIL                  */
/* 				  BD_ADMAPF.dbo.ADR_PAYMENT_FOR_ADDRESSEE           */
/*                BD_ADMAPF.dbo.ADR_PAYMENT_REGISTER                */
/* 				  BD_ADMAPF.dbo.----           */
/* Proposito    : Agregar permisos Simulaciones pendientes          */
/*                                                                  */
/*                   	                                            */
/* Empresa      : Scotiabank Chile				                    */
/*------------------------------------------------------------------*/

BEGIN

	DECLARE @ADR_ID_DUPLICATE BIGINT;
	DECLARE @REGISTER_ID BIGINT;
  
IF OBJECT_ID('tempdb..#DuplicateRecords') IS NOT NULL
        DROP TABLE #DuplicateRecords;
	

	WITH DuplicateRecords AS (
	    SELECT
	        PRE.REGISTER_ID, 
	        PRE.ADR_ID, 
	        PRE.ALIAS, 
	        PRE.RENAME, 
	        BNK.VALUE AS BANK_ID,
	        ACC.VALUE AS ACC_NUM,
	        TYPE_ACC.VALUE AS ACC_TYPE,
	        REG.CUSTOMER_ID,
	        REG.ADR_RUT AS RUT,
	        MET.ID_PAYMENT_METHOD AS PAYMENT_METHOD,
	        COUNT(*) OVER (
	            PARTITION BY REG.CUSTOMER_ID, REG.ADR_RUT, BNK.VALUE, ACC.VALUE, TYPE_ACC.VALUE, MET.ID_PAYMENT_METHOD
	        ) AS GroupCount,
	        ROW_NUMBER() OVER (
	            PARTITION BY REG.CUSTOMER_ID, REG.ADR_RUT, BNK.VALUE, ACC.VALUE, TYPE_ACC.VALUE, MET.ID_PAYMENT_METHOD
	            ORDER BY PRE.ALIAS ASC
	        ) AS RowNum
	    FROM BD_PORTALPYME.dbo.ADR_PAYMENT_REGISTER PRE
	    INNER JOIN BD_PORTALPYME.dbo.ADR_REGISTER REG ON REG.ADR_ID = PRE.ADR_ID
	    INNER JOIN BD_PORTALPYME.dbo.ADR_PAYMENT_DETAIL BNK ON BNK.REGISTER_ID = PRE.REGISTER_ID 
	        AND BNK.PAYMENT_KEY = 'bank_id   '
	    INNER JOIN BD_PORTALPYME.dbo.ADR_PAYMENT_DETAIL ACC ON ACC.REGISTER_ID = PRE.REGISTER_ID 
	        AND ACC.PAYMENT_KEY = 'acc_numbr '
	    INNER JOIN BD_PORTALPYME.dbo.ADR_PAYMENT_DETAIL TYPE_ACC ON TYPE_ACC.REGISTER_ID = PRE.REGISTER_ID 
	        AND TYPE_ACC.PAYMENT_KEY = 'acc_type  '
	    INNER JOIN BD_PORTALPYME.dbo.ADR_PAYMENT_FOR_ADDRESSEE MET ON MET.REGISTER_ID = PRE.REGISTER_ID
	   --WHERE REG.CUSTOMER_ID = '0713262005'
	)
	
	SELECT *
	INTO #DuplicateRecords
	FROM DuplicateRecords
	WHERE GroupCount > 1
	AND RowNum > 1;


PRINT '<<< LISTADO DE BENEFICIARIOS DUPLICADOS A ELIMINAR>>>';

SELECT count(*) as total_duplicados_a_eliminar FROM #DuplicateRecords; 


PRINT '<<< INICIO HOTFIX BENEFICIARIOS DUPLICADOS >>>';
WHILE EXISTS (SELECT 1 FROM #DuplicateRecords)
BEGIN
    SELECT TOP 1 
        @ADR_ID_DUPLICATE = ADR_ID,
        @REGISTER_ID = REGISTER_ID
    FROM #DuplicateRecords;

   /*
   
    DELETE FROM BD_PORTALPYME.dbo.ADR_PAYMENT_DETAIL
    WHERE REGISTER_ID = @REGISTER_ID;
    
    DELETE FROM BD_PORTALPYME.dbo.ADR_PAYMENT_FOR_ADDRESSEE
    WHERE REGISTER_ID = @REGISTER_ID;
   
    DELETE FROM BD_PORTALPYME.dbo.ADR_TEF_RESTRICTION
    WHERE REGISTER_ID = @REGISTER_ID;
   
    DELETE FROM BD_PORTALPYME.dbo.ADR_PAYMENT_REGISTER
    WHERE REGISTER_ID = @REGISTER_ID;
   
    */
    DELETE FROM #DuplicateRecords
    WHERE REGISTER_ID = @REGISTER_ID;
    
END

PRINT '<<< FIN HOTFIX BENEFICIARIOS DUPLICADOS >>>';


DROP TABLE #DuplicateRecords;

END;

