/*
 * %W% %E% Scotiabank Bank S.A
 *
 * Copyright (c) 2010-2024 Scotiabank Bank S.A, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Scotiabank
 * bank S.A, Inc. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Scotiabank.
 *
 * SCOTIABANK MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SCOTIABANK SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */
package com.bns.scoemcla.cefactoring.factory;


import cl.scotiabank.ce_factoring_web.v1.model.FactoringResponse;
import cl.scotiabank.ce_factoring_web.v1.model.Money;
import cl.scotiabank.ce_factoring_web.v1.model.OperationsList;
import cl.scotiabank.ce_factoring_web.v1.model.SimulationLastData;
import cl.scotiabank.ce_factoring_web.v1.model.SimulationLastResponse;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

/**
 * SimulationLast Factory
 *
 * @version 1.0.0 - 17 Dec 2024
 * @author Gustavo Ruiz - gustavo.ruiz_ex@scotiabank.cl (Imagemaker)
 * @since 1.0.0 - 17 Dec 2024
 *
 */

public class SimulationLastFactory {

    public static SimulationLastResponse getSimulationLast(cl.scotiabank.jo_factoring.v3.model.SimulationLastResponse simulationResponseJo) {
        return SimulationLastResponse.builder()
            .data(SimulationLastData.builder()
                .operationList(getListOperations(simulationResponseJo.getData().getOperationList()))
                .build())
            .response(FactoringResponse.builder()
                .responseCode(simulationResponseJo.getResponse().getResponseCode())
                .responseMessage(simulationResponseJo.getResponse().getResponseMessage())
                .build())
            .build();
    }

    public static List<OperationsList> getListOperations(List<cl.scotiabank.jo_factoring.v3.model.OperationsList> operationsListsJo) {
        return operationsListsJo.stream()
            .map(SimulationLastFactory::getListOperations)
            .collect(Collectors.toList());
    }

    public static OperationsList getListOperations(cl.scotiabank.jo_factoring.v3.model.OperationsList operationsListJo) {
        return OperationsList.builder()
            .operationId(
                new BigDecimal(operationsListJo.getOperationId().toString()))
            .documentQuantity(
                new BigDecimal(operationsListJo.getDocumentQuantity().toString()))
            .documentAmount(
                Money.builder()
                    .amount(operationsListJo.getDocumentAmount().getAmount())
                    .currencyCode(operationsListJo.getDocumentAmount().getCurrencyCode())
                    .build())
            .amountPay(
                Money.builder()
                    .amount(operationsListJo.getAmountPay().getAmount())
                    .currencyCode(operationsListJo.getAmountPay().getCurrencyCode())
                    .build())
            .build();
    }

}
