/*
 * %W% %E% Scotiabank Bank S.A
 *
 * Copyright (c) 2010-2024 Scotiabank Bank S.A, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Scotiabank
 * bank S.A, Inc. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Scotiabank.
 *
 * SCOTIABANK MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SCOTIABANK SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */
package com.bns.scoemcla.cefactoring.factory;


import cl.scotiabank.ce_factoring_web.v1.model.BatchInvoiceStatusData;
import cl.scotiabank.ce_factoring_web.v1.model.BatchInvoiceStatusResponse;
import cl.scotiabank.ce_factoring_web.v1.model.FactoringResponse;
import cl.scotiabank.jo_factoring.v3.model.BatchInvoicesList;
import cl.scotiabank.jo_factoring.v3.model.Money;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

/**
 * BatchInvoiceStatusFactory
 *
 * @version 1.0.0 - 18 Dec 2024
 * @author Gustavo Ruiz - gustavo.ruiz_ex@scotiabank.cl (Imagemaker)
 * @since 1.0.0 - 18 Dec 2024
 */

public class BatchInvoiceStatusFactory {

    public static BatchInvoiceStatusResponse getBatchInvoiceStatusResponse(cl.scotiabank.jo_factoring.v3.model.BatchInvoiceStatusResponse batchInvoiceStatusResponseJo) {

        return BatchInvoiceStatusResponse.builder()
            .data(getBatchInvoiceStatusData(batchInvoiceStatusResponseJo))
            .response(getBatchInvoiceStatusFactoringResponse(batchInvoiceStatusResponseJo.getResponse()))
            .build();
    }

    public static FactoringResponse getBatchInvoiceStatusFactoringResponse(cl.scotiabank.jo_factoring.v3.model.FactoringResponse response){

        return FactoringResponse.builder()
            .responseCode(response.getResponseCode())
            .responseMessage(response.getResponseMessage())
            .build();
    }

    public static BatchInvoiceStatusData getBatchInvoiceStatusData (cl.scotiabank.jo_factoring.v3.model.BatchInvoiceStatusResponse batchInvoiceStatusResponseJo) {

        return BatchInvoiceStatusData.builder().
            build()
            .batchInvoicesList(getBatchInvoicesLists(batchInvoiceStatusResponseJo.getData().getBatchInvoicesList()));

    }

    private static List<cl.scotiabank.ce_factoring_web.v1.model.BatchInvoicesList> getBatchInvoicesLists(List<BatchInvoicesList> response) {

        return response.stream()
            .map(BatchInvoiceStatusFactory::getBatchInvoicesList)
            .collect(Collectors.toList());
    }

    private static cl.scotiabank.ce_factoring_web.v1.model.BatchInvoicesList getBatchInvoicesList(BatchInvoicesList batchInvoicesList) {
        return cl.scotiabank.ce_factoring_web.v1.model.BatchInvoicesList.builder()
            .batchId(batchInvoicesList.getBatchId())
            .operationId(new BigDecimal(batchInvoicesList.getOperationId().toString()))
            .cessionId(batchInvoicesList.getCessionId())
            .amountApproved(batchInvoicesList.getAmountApproved().getAmount().toString()
                /*Money.builder()
                    .amount(batchInvoicesList.getAmountApproved().getAmount())
                    .currencyCode(batchInvoicesList.getAmountApproved().getCurrencyCode())
                    .build()*/
            )
            .amountOriginal(batchInvoicesList.getAmountOriginal().getAmount().toString()
                /*Money.builder()
                    .amount(batchInvoicesList.getAmountOriginal().getAmount())
                    .currencyCode(batchInvoicesList.getAmountOriginal().getCurrencyCode())
                    .build()*/
            )
            .requestMeasure(batchInvoicesList.getRequestMeasure())
            .status(batchInvoicesList.getStatus())
            .build();
    }
}