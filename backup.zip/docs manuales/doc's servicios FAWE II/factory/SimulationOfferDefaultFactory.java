/*
 * %W% %E% Scotiabank Bank S.A
 *
 * Copyright (c) 2010-2024 Scotiabank Bank S.A, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Scotiabank
 * bank S.A, Inc. ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Scotiabank.
 *
 * SCOTIABANK MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SCOTIABANK SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */
package com.bns.scoemcla.cefactoring.factory;


import cl.scotiabank.ce_factoring_web.v1.model.FactoringResponse;
import cl.scotiabank.ce_factoring_web.v1.model.Money;
import cl.scotiabank.ce_factoring_web.v1.model.SimulationOfferData;
import cl.scotiabank.ce_factoring_web.v1.model.SimulationOfferResponse;

import java.util.stream.Collectors;

/**
 * SimulationOfferDefault Factory
 *
 * @version 1.0.0 - 18 Ded 2024
 * @author Gustavo Ruiz - gustavo.ruiz_ex@scotiabank.cl (Imagemaker)
 * @since 1.0.0 - 18 Dec 2024
 */
public class SimulationOfferDefaultFactory {

    public static SimulationOfferResponse getSimulationOffer(cl.scotiabank.jo_factoring.v3.model.SimulationOfferResponse simulationOfferResponseJo) {
        return SimulationOfferResponse.builder()
            .data(SimulationOfferData.builder()
                .operationDate(simulationOfferResponseJo.getData().getOperationDate())
                .customerRut(simulationOfferResponseJo.getData().getCustomerRut())
                .customerCompanyName(simulationOfferResponseJo.getData().getCustomerCompanyName())
                .cessionId(simulationOfferResponseJo.getData().getCessionId())
                .invoiceNumber(simulationOfferResponseJo.getData().getInvoiceNumber().intValue())
                .operationBills(simulationOfferResponseJo.getData().getOperationBills().getAmount())
                .discountFee(simulationOfferResponseJo.getData().getDiscountFee())
                .commission(simulationOfferResponseJo.getData().getCommission().getAmount())
                .vatCommission(simulationOfferResponseJo.getData().getVatCommission().getAmount())
                .operationAmount(simulationOfferResponseJo.getData().getOperationAmount().getAmount())
                .advanceAmount(simulationOfferResponseJo.getData().getAdvanceAmount().getAmount())
                .totalWithdrawAmount(simulationOfferResponseJo.getData().getTotalWithdrawAmount().getAmount())
                .priceDifference(simulationOfferResponseJo.getData().getPriceDifference().getAmount())
                .build())
            .response(FactoringResponse.builder()
                .responseCode(simulationOfferResponseJo.getResponse().getResponseCode())
                .responseMessage(simulationOfferResponseJo.getResponse().getResponseMessage())
                .build())
            .build();
    }

}
